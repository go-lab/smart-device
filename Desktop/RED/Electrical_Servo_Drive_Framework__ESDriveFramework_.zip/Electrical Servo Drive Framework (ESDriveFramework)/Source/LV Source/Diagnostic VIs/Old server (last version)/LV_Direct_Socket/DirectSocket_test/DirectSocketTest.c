/*
 *  DirectSocketTest.c
 *  DirectSocket_test
 *
 *  Created by Chris on 2/2/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

//#include "DirectSocketTest.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

int DirectSocketTest(int sockfd);
int DirectSocketTest(int sockfd)

{
	//	int sockfd=0x2B;
	char *msg = "DirectSocketAccess success";
	int len, bytes_sent;
	
	//	if (argc != 2)
	//		printf("usage: a.out <sockfd>");
	
	//sockfd=argv[1];
	//	printf("argv[1]: %s\n",argv[1]);
	//	sockfd=atoi(argv[1]);
	len = strlen(msg);
	printf("sockfd: %d\n",sockfd);
	bytes_sent = send(sockfd, msg, len, 0);
	printf("len: %d, bytes_sent: %d\n",len,bytes_sent);
	perror("DirectSocketTest");
	
	return errno;
	
}


int DirectSocketTest2(int sockfd);
int DirectSocketTest2(int sockfd)

{
	//	int sockfd=0x2B;
	char *msg = "DirectSocketAccess success";
	int len, bytes_sent;
	int val, err;
	socklen_t len2;
	
	//	if (argc != 2)
	//		printf("usage: a.out <sockfd>");
	
	//sockfd=argv[1];
	//	printf("argv[1]: %s\n",argv[1]);
	//	sockfd=atoi(argv[1]);
	len = strlen(msg);
	fprintf(stderr,"sockfd: %d\n",sockfd);
	bytes_sent = send(sockfd, msg, len, 0);
	fprintf(stderr,"len: %d, bytes_sent: %d\n",len,bytes_sent);
	perror("DirectSocketTest2");
	len2=sizeof(val);
	err=getsockopt(sockfd,SOL_SOCKET,SO_NWRITE,&val,&len2);
	fprintf(stderr,"SO_NWRITE, err: %d, errno: %d, val: %d\n", err, errno,val);
	len2=sizeof(val);
	err=getsockopt(sockfd,SOL_SOCKET,SO_SNDBUF,&val,&len2);
	fprintf(stderr,"SO_SNDBUF, err: %d, errno: %d, val: %d\n", err, errno,val);
	len2=sizeof(val);
	err=getsockopt(sockfd,SOL_SOCKET,SO_NWRITE,&val,&len2);
	fprintf(stderr,"SO_NWRITE 2, err: %d, errno: %d, val: %d\n", err, errno,val);
	if (err) perror("myGetSockOpt2");
	
	return errno;
	
}


int DirectSocketTest3(int sockfd, char *buff, int *len, int *val);
int DirectSocketTest3(int sockfd, char *buff, int *len, int *val)

{
	//	int sockfd=0x2B;
//	char *msg = "DirectSocketAccess success";
	//int bytes_sent;
	int err;
	socklen_t len2;
	
	//	if (argc != 2)
	//		printf("usage: a.out <sockfd>");
	
	//sockfd=argv[1];
	//	printf("argv[1]: %s\n",argv[1]);
	//	sockfd=atoi(argv[1]);
	//len = strlen(msg);
	//fprintf(stderr,"sockfd: %d\n",sockfd);
	if (*len >0)
		*len = send(sockfd, buff, *len, 0);
	//fprintf(stderr,"len: %d, bytes_sent: %d\n",len,bytes_sent);
	//perror("DirectSocketTest2");
	len2=sizeof(val);
	err=getsockopt(sockfd,SOL_SOCKET,SO_NWRITE,val,&len2);
	//fprintf(stderr,"SO_NWRITE3, err: %d, errno: %d, val: %d\n", err, errno,*val);
	if (err) perror("myGetSockOpt3");
	
	return errno;
	
}


long myGetSockOpt(int socket, int level, int option_name, void *restrict option_value, socklen_t *restrict option_len);
long myGetSockOpt(int socket, int level, int option_name, void *restrict option_value, socklen_t *restrict option_len){
	int err=0;
	err=getsockopt(socket,level,option_name,option_value,option_len);
	fprintf(stderr,"myGetSockOpt, level: %d, Opt: %d, val:% d, len: %d, err: %d, errno: %d\n",level,option_name,*(int*)option_value,*(int*)option_len, err, errno);
	if (err) perror("myGetSockOpt");
	return errno;
}